package CLIPSJNI;

public class VoidValue extends PrimitiveValue
  {
   /***************/
   /* VoidValue: */
   /***************/
   public VoidValue()
     {
      super(null);
     }
  }
