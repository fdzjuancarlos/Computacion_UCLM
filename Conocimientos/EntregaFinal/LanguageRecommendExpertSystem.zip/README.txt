

IN ORDER TO EXECUTE THIS EXPERT SYSTEM:

You’ll need “java” and “javac” installed on your Terminal. Go to the path
where the expert system is installed, and execute “make”, if you’re on Windows OS
execute this:

	java -cp .;./CLIPSJNI.jar -Djava.library.path=./ RecommendSystem

If you’re not able to load the Expert System, try compiling it with:

	javac -classpath ./CLIPSJNI.jar RecommendSystem.java
	java -cp .;./CLIPSJNI.jar -Djava.library.path=./ RecommendSystem

Any question you can email us:

fdz.juancarlos@gmail.com
victor.buke@gmail.com